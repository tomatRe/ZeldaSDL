﻿
class Wall : Sprite
{
    public Wall()
    {
        SpriteX = 351;
        SpriteY = 50;
    }

    public Wall(short X, short Y)
    {
        this.X = X;
        this.Y = Y;
    }
}

