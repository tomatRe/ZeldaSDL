﻿
class EnemySpawn : Sprite
{
    public EnemySpawn(short X, short Y)
    {
        this.X = X;
        this.Y = Y;
    }
}


