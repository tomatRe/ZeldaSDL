﻿
class PlayerSpawn : Sprite
{
    public PlayerSpawn(short X, short Y)
    {
        this.X = X;
        this.Y = Y;
    }
}

