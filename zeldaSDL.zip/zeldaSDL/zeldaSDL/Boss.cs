﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Boss : Sprite
{

    //To Do All

    public Boss()
    {
        Console.WriteLine("Boss Spawned!");
    }

    public void MoveUp()
    {
        //To do
    }

    public void Movedown()
    {
        //To do
    }

    public void MoveLeft()
    {
        //To do
    }

    public void MoveRight()
    {
        //To do
    }

    public void FireMain()
    {
        //To do
    }

    public void FireSpecial()
    {
        //To do
    }

    public void Jump()
    {
        //To do
    }

}