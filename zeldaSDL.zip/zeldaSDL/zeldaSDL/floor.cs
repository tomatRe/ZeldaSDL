﻿
class Floor : Sprite
{
    public Floor()
    {
        SpriteX = 223;
        SpriteY = 463;
    }

    public Floor(short X, short Y)
    {
        this.X = X;
        this.Y = Y;
    }
}